package br.com.dito.restaurante.controller;
import br.com.dito.restaurante.DTO.ProdutoDTO;
import br.com.dito.restaurante.service.ProdutoService;
//import br.com.dito.restaurante.repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
//import java.util.stream.Collectors;

@RestController
@RequestMapping("/produtos")
public class ProdutoController {

    private final ProdutoRepository produtoRepository;

    @Autowired
    public ProdutoService produtoService;


    @PostMapping
    public Produto atualizarProduto(@PathVariable Long id, @RequestBody Produto produtoAtualizado){
        Produto produto = produtoRepository.findById(id).orElseThrow();
        produto.setNome(produtoAtualizado.getNome());
        produto.setPreco(produtoAtualizado.getPreco());
        return produtoRepository.save(produto);
    }

    @GetMapping
    public List<ProdutoDTO> listarTodos(){
        return produtoService.listarTodos();
    }

    @PostMapping
    public ProdutoDTO criarProduto(@RequestBody ProdutoDTO dto){
        return produtoService.adicionarProduto(dto);
    }

    @PutMapping
    public ProdutoDTO atualizarProduto(@PathVariable Long id, @RequestBody ProdutoDTO dto){
        return produtoService.atualizarProduto(id, dto);
    }

    @DeleteMapping("/{id}")
    public void deletarProduto(@PathVariable Long id){
        produtoService.deletarProduto(id);
    }
    @GetMapping("/preços")//ENDPOINT
        public List<ProdutoDTO> buscarEntrePrecos(@RequestParam Double min,@RequestParam Double max) {
        return produtoService.buscarProdutosEntrePrecos(min,max);
}
}